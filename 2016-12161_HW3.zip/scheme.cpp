//Data_Structure_Project1_Scheme Interpreter_2016-12161_Taewon Lee
//Hash_Table, Node_Array are implemented with class, snake_Case
//Other function: camelCase
//all command should start with '('
//doesn't return the input when input doesn't start with '('
//since it doesn't make Node_Array
//variable(variable is one variable
#include <iostream>
#include <cstring>
using namespace std;

//constructor will be added as the project goes on
class Hash_Table
{
public:
    int hashFind(string hashKey); //check the value is in hash & read from it
    void print();                 //print the hash_table
    string hashValue(int hashKey);

private:
    int capacity = 10;
    class hash_cell
    {
        friend Hash_Table;
        string Symbol;
        hash_cell *link;
    };
    hash_cell *hash_table = new hash_cell[capacity];
};

//nextRoot is controlled by variable current(root at now)
//constructor will be added as the project goes on
class Node_Array
{
public:
    int Read(string *token, Hash_Table *HT);      //read the scheme command(build the structure)
    void print();                                 //print the Node_Array
    int nextRoot() { return current + 1; }        //return the Root of free List
    string readCommand(int root, Hash_Table *HT); //return the command according to the Node_array built
    void free(int root);

private:
    class node_cell
    {
        friend Node_Array;
        int left, right;
    };
    int capacity = 30;
    int current = 0;
    node_cell *node_array = new node_cell[capacity];
};

//functions needed
string tolower(string input);       //change CAPITAL to lower case
unsigned int StringToInt(string s); //change string to int, to get a hash_key
// string preprocess(string *input);  will be added as the project goes on

int main()
{
    Hash_Table HT;
    Node_Array NA;
    while (true)
    {
        string input;
        cout << "> ";
        getline(cin, input);
        input = tolower(input);
        string line = input;
        //        preprocess(&input);
        int root = NA.Read(&input, &HT);
        int printRoot = (root < 0) ? -1 : root;
        cout << "] Free list's root = " << NA.nextRoot() << endl;
        cout << "List's root = " << printRoot << endl;
        NA.print();
        HT.print();
        if (root > 0)
        {
            cout << "input: (" << NA.readCommand(root, &HT) << endl; //print the input
            NA.free(root);                                           //deallocate the memory array
        }
    }
    return 0;
}

int Hash_Table::hashFind(string hashKey)
{
    int hashValue = StringToInt(hashKey) % capacity;
    int temp = hashValue;
    for (int i = 0; i < capacity; i++)
    {
        //since deleting hash is not implemented yet
        if (hashKey.compare(hash_table[hashValue].Symbol) == 0 || hash_table[hashValue].Symbol.empty())
        {
            hash_table[hashValue].Symbol = hashKey;
            return -hashValue;
        }
        hashValue = (hashValue + 1) % capacity;
    }
    throw runtime_error("hash is full for now");
};

unsigned int StringToInt(string s)
//following the pseudo code
{
    int length = (int)s.length();
    unsigned int answer = 0;
    if (length % 2 == 1)
    {
        answer = s.at(length - 1);
        length--;
    }
    for (int i = 0; i < length; i += 2)
    {
        answer += s.at(i);
        answer += ((int)s.at(i + 1)) << 8;
    }
    return answer;
};

string next_token(string *sentence)
{
    if (sentence->empty())
        return "";
    int k = sentence->find(" ");
    if (k == 0) //remove useless space
        return next_token(&(*sentence = sentence->substr(1, -1)));
    string symbol = sentence->substr(0, k);
    if (symbol.at(0) == '(' || symbol.at(0) == ')') // separating (state to ( state
    {
        symbol = symbol.at(0);
        *sentence = sentence->substr(1, -1);
        return symbol;
    }
    if (symbol.back() == ')' || symbol.back() == '(') //separating state) to state )
    {
        while (symbol.back() == ')' || symbol.back() == '(')
            symbol.pop_back();
        *sentence = sentence->substr(symbol.length(), -1);
        return symbol;
    }
    if (k != -1)
        *sentence = sentence->substr(k, -1);
    if (k == -1)
        *sentence = "";
    return symbol;
}

int Node_Array::Read(string *input, Hash_Table *HT)
//following the pseudo code
{
    int root = 0;
    bool first = true;
    int token_hash_value = HT->hashFind(next_token(input));
    if (token_hash_value == HT->hashFind("("))
    {
        int temp;
        token_hash_value = HT->hashFind(next_token(input));
        while (token_hash_value != HT->hashFind(")"))
        {
            if (first)
            {
                //root = temp = alloc();
                current++;
                if (current == capacity)
                    throw runtime_error("node is full for now");
                root = temp = current;
                first = false;
            }
            else
            {
                //node_array[temp].right = alloc();
                current++;
                if (current == capacity)
                    throw runtime_error("node is full for now");
                node_array[temp].right = current;
                temp = node_array[temp].right;
            }
            if (token_hash_value == HT->hashFind("("))
            {
                *input = "(" + *input;
                node_array[temp].left = Read(input, HT);
            }
            else
                node_array[temp].left = token_hash_value;
            if (!first)
                node_array[temp].right = HT->hashFind(")");
            token_hash_value = HT->hashFind(next_token(input));
        }
        return root;
    }
    else
        return token_hash_value;
}
string Hash_Table::hashValue(int hashKey)
{
    if (hashKey <= 0)
        return hash_table[-hashKey].Symbol;
    return "error";
}
void Node_Array::print()
{
    cout << " ========== Memory Array ==========" << endl;
    for (int i = 1; i < current + 1; i++)
        cout << "node: " << i << " l:" << node_array[i].left << " r:" << node_array[i].right << endl;
}
void Hash_Table::print()
{
    cout << " ========== Hash_Table ==========" << endl;
    for (int i = 0; i < capacity; i++)
        if (!hash_table[i].Symbol.empty())
            cout << "index: " << i << " symbol: " << hash_table[i].Symbol << endl;
}

string tolower(string input)
{
    int length = input.length();
    string output = "";
    char onec;
    for (int i = 0; i < length; i++)
        output += onec = (input.at(i) >= 'A' && input.at(i) <= 'Z') ? input.at(i) + 32 : input.at(i);
    return output;
}

string Node_Array::readCommand(int root, Hash_Table *HT)
{
    if (root < 1)
        return "";
    string command = "";
    if (node_array[root].left > 0)
        command += "(" + readCommand(node_array[root].left, HT);
    else
        command += " " + HT->hashValue(node_array[root].left);
    if (node_array[root].right > 0)
        command += readCommand(node_array[root].right, HT);
    else
        command += " " + HT->hashValue(node_array[root].right);
    return command;
}
void Node_Array::free(int root) { current = root - 1; }
