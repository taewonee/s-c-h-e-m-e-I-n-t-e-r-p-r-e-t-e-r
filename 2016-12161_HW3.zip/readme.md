Scheme Interpreter ver 1.
Windows10, g++ version 8.1.0

- Steps:
1. get a line as an input
2. preprocess(input)
    : remove meaningless parenthesis
3. build a node_tree class(implemented by array) based on input
4. build a hash_table class based on input
5. print node_tree & hash_table & input

 - Additional Info :
1. suppose there is no input error for now (always start with '(')
2. node Capacity: 300, Hash Capacity: 10;
3. predefined hash table: not yet

